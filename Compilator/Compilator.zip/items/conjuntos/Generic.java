package items.conjuntos;

public interface Generic{}
