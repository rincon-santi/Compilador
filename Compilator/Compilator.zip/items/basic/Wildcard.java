package items.basic;

public class Wildcard extends Dimension{
    public Wildcard(){}

    @Override
    public String toString(){
        return "Dimension _";
    }
}
