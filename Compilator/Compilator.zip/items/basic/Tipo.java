package items.basic;

public enum Tipo{
    ENT, BOOL, NULL;
}
