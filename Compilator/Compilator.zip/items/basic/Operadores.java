package items.basic;

public enum Operadores {
    NEG, POR, CON, MAS, MENOS, DIS, MENOR, MAYOR, MENOROIGUAL, MAYOROIGUAL, IGUAL, DIFF;
}
